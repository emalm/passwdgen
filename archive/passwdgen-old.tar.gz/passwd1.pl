#!/usr/bin/perl -w
use strict;
use Digest::BubbleBabble qw( bubblebabble );
use Digest::SHA1 qw( sha1 );

my $uuid = `c:/Program Files/MSVS/Common/Tools/UUIDGEN.EXE`;
chomp $uuid;
$uuid =~ s/-//g;

my $sha = sha1( $uuid );
my $fingerprint = bubblebabble( Digest => $sha );

while ($fingerprint =~ /(?<=-)(\w{5})(?=-)/g) {
    my $randint = int( 100 * rand() );
    print "$1" . sprintf("%02i", $randint) . "\n";
}