#!/usr/bin/perl -w
use strict;

sub consonant;
sub vowel;
sub password_gen;

my @CONSONANTS = qw( b c d f g h k l m n p r s t v z x );
my @VOWELS = qw( a e i o u y );
my $i;

for ($i = 1; $i <= 10; $i++) {
    print password_gen() . "\n";
}

sub consonant {
    my $index;
    $index = int( scalar @CONSONANTS * rand() );
    return $CONSONANTS[$index];
}

sub vowel {
    my $index;
    $index = int( scalar @VOWELS * rand() );
    return $VOWELS[$index];
}

sub password_gen {
    my $randint = int( 100 * rand() );
    my $letterstring = consonant() . vowel() . consonant() . vowel() . consonant() . vowel() . consonant();
    return ($letterstring . sprintf("%02i", $randint));
}